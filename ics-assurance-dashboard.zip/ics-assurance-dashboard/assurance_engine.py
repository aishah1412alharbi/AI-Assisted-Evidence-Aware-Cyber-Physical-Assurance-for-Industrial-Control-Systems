# AI-Assisted Evidence-Aware Cyber-Physical Assurance for ICS — Prototype
# AI-assisted anomaly detection + rule-based evidence fusion
#
# Prototype note:
# The default training/evaluation data is synthetic. Do not describe
# simulated results as real-world accuracy. Isolation Forest detects
# unusual patterns; it does not prove that an attack occurred.

import csv
import os
import random
import numpy as np
from sklearn.ensemble import IsolationForest

SAFE_LIMITS = {
    "pressure": (0, 85),
    "rpm": (0, 2000),
    "valve_angle": (0, 90),
    "vibration": (0, 50),
}

EXPECTED_ANGLE = {
    "OPEN_VALVE": 70,
    "CLOSE_VALVE": 10,
    "ADJUST_PRESSURE": 50,
}

UNITS = {
    "pressure": "bar",
    "rpm": "rpm",
    "valve_angle": "deg",
    "vibration": "mm/s",
}

ACTIONS = {
    "SAFE": "ALLOW — continue monitoring",
    "SUSPICIOUS": "VERIFY — request operator verification",
    "CRITICAL": "BLOCK — raise security alert",
}


# ---------------- DATA ----------------

def generate_sensor_data(case=None):
    """Synthetic scenarios for prototype testing only."""
    case = case or random.choice(
        ["NORMAL", "SUSPICIOUS", "CRITICAL", "STEALTH_SCENARIO"]
    )
    command = random.choice(list(EXPECTED_ANGLE))
    expected = EXPECTED_ANGLE[command]

    if case == "NORMAL":
        pressure = random.uniform(45, 75)
        rpm = random.randint(900, 1700)
        valve_angle = expected + random.uniform(-8, 8)
        vibration = random.uniform(10, 45)
        vib_change = random.uniform(0, 8)
        attempts = random.randint(1, 5)
        rejected = random.randint(0, 1)

    elif case == "SUSPICIOUS":
        pressure = random.uniform(60, 82)
        rpm = random.randint(1500, 1950)
        valve_angle = expected + random.choice([-1, 1]) * random.uniform(12, 24)
        vibration = random.uniform(40, 50)
        vib_change = random.uniform(8, 18)
        attempts = random.randint(7, 12)
        rejected = random.randint(2, 4)

    elif case == "STEALTH_SCENARIO":
        # An anomalous low-and-slow synthetic scenario that stays
        # inside fixed safety limits. It is NOT a real attack.
        pressure = random.uniform(78, 85)
        rpm = random.randint(1850, 2000)
        valve_angle = expected + random.uniform(-8, 8)
        vibration = random.uniform(44, 50)
        vib_change = random.uniform(0, 8)
        attempts = random.randint(1, 5)
        rejected = random.randint(0, 1)

    else:  # CRITICAL synthetic scenario
        pressure = random.uniform(90, 105)
        rpm = random.randint(2100, 2500)
        valve_angle = random.uniform(100, 120)
        vibration = random.uniform(60, 80)
        vib_change = random.uniform(15, 35)
        attempts = random.randint(15, 25)
        rejected = random.randint(5, 10)

    return {
        "scenario": case,
        "command": command,
        "pressure": pressure,
        "rpm": rpm,
        "valve_angle": min(max(0, valve_angle), 120),
        "vibration": vibration,
        "previous_vibration": max(0, vibration - vib_change),
        "attempts": attempts,
        "rejected": rejected,
    }


def ai_features(data):
    return [
        data["pressure"],
        data["rpm"],
        data["valve_angle"],
        data["vibration"],
        abs(data["vibration"] - data["previous_vibration"]),
        abs(data["valve_angle"] - EXPECTED_ANGLE[data["command"]]),
        data["attempts"],
        data["rejected"],
    ]


def load_real_data(csv_path):
    """Load real NORMAL-operation readings from a CSV."""
    rows = []
    required = [
        "command", "pressure", "rpm", "valve_angle", "vibration",
        "previous_vibration", "attempts", "rejected"
    ]

    with open(csv_path, newline="", encoding="utf-8") as f:
        for row in csv.DictReader(f):
            for key in required:
                if key not in row:
                    raise ValueError(f"Missing CSV column: {key}")

            data = {"command": row["command"].strip()}
            for key in required[1:]:
                data[key] = float(row[key])
            rows.append(ai_features(data))

    if not rows:
        raise ValueError("CSV contains no data rows.")
    return rows


# ---------------- AI LAYER ----------------

def train_ai_model(n_samples=1500, csv_path=None):
    """
    Train Isolation Forest on NORMAL-operation data only.
    Real CSV can replace the synthetic training data.
    """
    if csv_path:
        rows = load_real_data(csv_path)
        source = "REAL NORMAL-OPERATION CSV"
    else:
        rows = [
            ai_features(generate_sensor_data("NORMAL"))
            for _ in range(n_samples)
        ]
        source = "SIMULATED NORMAL-OPERATION DATA"

    model = IsolationForest(
        n_estimators=200,
        contamination=0.03,
        random_state=42,
    )
    model.fit(np.asarray(rows))
    return model, source


# Set a CSV path here when real normal-operation data is available.
REAL_NORMAL_CSV = None
ai_model, AI_TRAINING_SOURCE = train_ai_model(csv_path=REAL_NORMAL_CSV)


def ai_analysis(data):
    """
    Detect unusual patterns relative to learned NORMAL operation.
    This does not identify an attacker or prove an attack.
    """
    values = np.asarray([ai_features(data)])
    prediction = ai_model.predict(values)[0]
    score = float(ai_model.decision_function(values)[0])
    return ("AI ANOMALY" if prediction == -1 else "AI NORMAL"), score


# ---------------- DETECTION LAYERS ----------------

def physical_rules(data):
    violations = []
    for sensor, (low, high) in SAFE_LIMITS.items():
        if not (low <= data[sensor] <= high):
            violations.append(sensor)
    return ("ANOMALY", violations) if violations else ("NORMAL", [])


def physical_fingerprint(data):
    change = abs(data["vibration"] - data["previous_vibration"])
    if change <= 10:
        return "NORMAL", change
    if change <= 20:
        return "UNUSUAL", change
    return "ABNORMAL", change


def expected_vs_observed(data):
    expected = EXPECTED_ANGLE[data["command"]]
    diff = abs(data["valve_angle"] - expected)
    if diff <= 10:
        return "CONSISTENT", diff
    if diff <= 20:
        return "UNUSUAL", diff
    return "MISMATCH", diff


def cyber_behavior_analysis(data):
    """Command-activity indicator; not proof of an attacker."""
    score = 0
    if data["attempts"] > 10:
        score += 15
    elif data["attempts"] > 6:
        score += 8

    if data["rejected"] > 3:
        score += 15
    elif data["rejected"] > 1:
        score += 8

    if score >= 20:
        return "SUSPICIOUS", score
    if score >= 10:
        return "UNUSUAL", score
    return "NORMAL", score


def context_engine(rule, fingerprint, consistency, cyber_behavior):
    statuses = [rule, fingerprint, consistency, cyber_behavior]
    indicators = sum(
        status in ["ANOMALY", "ABNORMAL", "MISMATCH", "SUSPICIOUS"]
        for status in statuses
    )
    if indicators >= 3:
        return "HIGH"
    if indicators == 2:
        return "MEDIUM"
    if indicators == 1:
        return "LOW"
    return "NORMAL"


# ---------------- RISK FUSION ----------------

def classify_risk(rule, fingerprint, consistency, cyber_behavior,
                  context, ai_status):
    score = 0
    reasons = []

    if rule == "ANOMALY":
        score += 30
        reasons.append("Sensor outside defined safety limits (+30)")

    if fingerprint == "ABNORMAL":
        score += 20
        reasons.append("Abnormal vibration change (+20)")
    elif fingerprint == "UNUSUAL":
        score += 10
        reasons.append("Unusual vibration change (+10)")

    if consistency == "MISMATCH":
        score += 20
        reasons.append("Observed valve angle mismatches command (+20)")
    elif consistency == "UNUSUAL":
        score += 10
        reasons.append("Observed valve angle differs from command (+10)")

    if cyber_behavior == "SUSPICIOUS":
        score += 20
        reasons.append("Suspicious command-activity pattern (+20)")
    elif cyber_behavior == "UNUSUAL":
        score += 10
        reasons.append("Unusual command-activity pattern (+10)")

    if context == "HIGH":
        score += 20
        reasons.append("Multiple rule-based indicators agree (+20)")
    elif context == "MEDIUM":
        score += 10
        reasons.append("Two rule-based indicators agree (+10)")

    if ai_status == "AI ANOMALY":
        score += 25
        reasons.append("AI anomaly detector flagged an unusual pattern (+25)")

    score = min(score, 100)
    level = "CRITICAL" if score >= 70 else "SUSPICIOUS" if score >= 40 else "SAFE"
    return score, level, reasons


# ---------------- PIPELINE ----------------

def analyze(data, verbose=True, use_ai=True):
    rule, violations = physical_rules(data)
    fingerprint, fp_change = physical_fingerprint(data)
    consistency, cons_diff = expected_vs_observed(data)
    cyber_behavior, cyber_score = cyber_behavior_analysis(data)

    context = context_engine(
        rule, fingerprint, consistency, cyber_behavior
    )

    ai_status, ai_score = ai_analysis(data)
    effective_ai = ai_status if use_ai else "AI DISABLED"

    score, level, reasons = classify_risk(
        rule, fingerprint, consistency,
        cyber_behavior, context, effective_ai
    )

    results = {
        "rule": rule,
        "violations": violations,
        "fingerprint": fingerprint,
        "fp_change": fp_change,
        "consistency": consistency,
        "cons_diff": cons_diff,
        "cyber_behavior": cyber_behavior,
        "cyber_score": cyber_score,
        "context": context,
        "ai": effective_ai,
        "ai_score": ai_score,
        "score": score,
        "level": level,
        "reasons": reasons,
    }

    if verbose:
        print_report(data, results)
    return data, results


def assurance_run(case=None, verbose=True, use_ai=True, noise=0.0, data=None):
    data = data or generate_sensor_data(case)
    if noise:
        data = add_noise(data, noise)
    return analyze(data, verbose=verbose, use_ai=use_ai)


# ---------------- OUTPUT ----------------

def risk_bar(score, width=20):
    filled = int(score / 100 * width)
    return "[" + "#" * filled + "-" * (width - filled) + f"] {score}/100"


def print_report(data, results):
    line = "=" * 58
    print(f"\n{line}")
    print("          CYBER-PHYSICAL ASSURANCE — SECURITY REPORT")
    print(line)
    print(f"Scenario (simulated): {data.get('scenario', 'REAL')}")
    print(f"Command received    : {data['command']}")

    print("\n--- Sensor Readings ---")
    for sensor, (low, high) in SAFE_LIMITS.items():
        value = data[sensor]
        flag = "OK" if low <= value <= high else "OUT OF RANGE"
        print(
            f"{sensor:<12}: {value:8.2f} {UNITS[sensor]:<5} "
            f"(limit {high}) [{flag}]"
        )
    print(
        f"{'attempts':<12}: {data['attempts']:>8}   "
        f"rejected: {data['rejected']}"
    )

    print("\n--- Detection Layers ---")
    print(
        f"Physical Rules       : {results['rule']}"
        + (f" -> {', '.join(results['violations'])}"
           if results["violations"] else "")
    )
    print(
        f"Physical Fingerprint : {results['fingerprint']} "
        f"(change {results['fp_change']:.1f})"
    )
    print(
        f"Expected / Observed  : {results['consistency']} "
        f"(difference {results['cons_diff']:.1f})"
    )
    print(
        f"Cyber-Behavior       : {results['cyber_behavior']} "
        f"(score {results['cyber_score']})"
    )
    print(f"Evidence Context     : {results['context']}")
    print(
        f"AI Anomaly Detection : {results['ai']} "
        f"(score {results['ai_score']:+.3f})"
    )

    print("\n--- Risk Assessment ---")
    for reason in results["reasons"] or ["No risk indicators found"]:
        print(f"  * {reason}")

    print(f"\nRisk Score : {risk_bar(results['score'])}")
    print(f"Risk Level : {results['level']}")

    action = ACTIONS[results["level"]]

    # AI-only anomaly should be treated as a review signal, not proof.
    non_ai_score = results["score"] - (
        25 if results["ai"] == "AI ANOMALY" else 0
    )
    if (
        results["ai"] == "AI ANOMALY"
        and non_ai_score < 40
        and results["level"] == "SAFE"
    ):
        action = "FLAG — AI anomaly detected; review before escalation"

    print(f"Action     : {action}")
    print(f"AI training: {AI_TRAINING_SOURCE}")
    print(line)


def add_noise(data, level):
    noisy = dict(data)
    for key in [
        "pressure", "rpm", "valve_angle",
        "vibration", "previous_vibration"
    ]:
        noisy[key] = max(
            0.0, data[key] * (1 + random.gauss(0, level))
        )
    return noisy


def log_result(data, results, path="assurance_log.csv"):
    row = {
        **{
            k: round(v, 2) if isinstance(v, float) else v
            for k, v in data.items()
        },
        "risk_score": results["score"],
        "risk_level": results["level"],
        "ai": results["ai"],
        "ai_score": round(results["ai_score"], 4),
        "context": results["context"],
    }

    new_file = not os.path.exists(path)
    with open(path, "a", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=list(row))
        if new_file:
            writer.writeheader()
        writer.writerow(row)


# ---------------- SIMULATION EVALUATION ----------------

def evaluate(n=500):
    """
    Evaluate synthetic scenarios only.
    Do not call this real-world detection accuracy.
    """
    expected = {
        "NORMAL": "SAFE",
        "SUSPICIOUS": "SUSPICIOUS",
        "CRITICAL": "CRITICAL",
    }
    levels = ["SAFE", "SUSPICIOUS", "CRITICAL"]
    matrix = {
        scenario: {level: 0 for level in levels}
        for scenario in expected
    }
    ai_flags = {}

    for scenario in list(expected) + ["STEALTH_SCENARIO"]:
        ai_flags[scenario] = 0

        for _ in range(n):
            _, result = assurance_run(
                scenario, verbose=False, use_ai=True
            )
            ai_flags[scenario] += result["ai"] == "AI ANOMALY"

            if scenario in matrix:
                matrix[scenario][result["level"]] += 1

    print("\n" + "=" * 70)
    print(f"SIMULATED SCENARIO EVALUATION — {n} runs/scenario")
    print("=" * 70)

    correct_total = 0
    for scenario, row in matrix.items():
        correct = row[expected[scenario]]
        correct_total += correct
        print(
            f"{scenario:<20} "
            f"SAFE={row['SAFE']:<4} "
            f"SUSPICIOUS={row['SUSPICIOUS']:<4} "
            f"CRITICAL={row['CRITICAL']:<4} "
            f"match={correct/n*100:5.1f}%"
        )

    print(
        f"Overall simulated scenario match rate: "
        f"{correct_total / (3*n) * 100:.1f}%"
    )

    print("\nAI anomaly flags:")
    for scenario in ["NORMAL", "SUSPICIOUS", "CRITICAL", "STEALTH_SCENARIO"]:
        print(f"{scenario:<20}: {ai_flags[scenario]/n*100:5.1f}%")

    # Same synthetic stealth scenario with and without AI.
    with_ai = without_ai = 0
    for _ in range(n):
        _, r_ai = assurance_run(
            "STEALTH_SCENARIO", verbose=False, use_ai=True
        )
        _, r_rules = assurance_run(
            "STEALTH_SCENARIO", verbose=False, use_ai=False
        )
        with_ai += r_ai["level"] != "SAFE"
        without_ai += r_rules["level"] != "SAFE"

    print("\nAI contribution on STEALTH_SCENARIO:")
    print(f"Non-SAFE with AI   : {with_ai/n*100:5.1f}%")
    print(f"Non-SAFE without AI: {without_ai/n*100:5.1f}%")

    print("\nSynthetic sensor-noise robustness:")
    m = max(200, n // 2)
    for noise in [0.0, 0.03, 0.06, 0.10]:
        matched = 0
        for scenario, wanted in expected.items():
            for _ in range(m):
                _, result = assurance_run(
                    scenario, verbose=False, noise=noise
                )
                matched += result["level"] == wanted
        print(
            f"noise {noise*100:>4.0f}% : "
            f"{matched/(3*m)*100:5.1f}% simulated match rate"
        )


if __name__ == "__main__":
    for scenario in [
        "NORMAL", "SUSPICIOUS", "CRITICAL", "STEALTH_SCENARIO"
    ]:
        data, result = assurance_run(scenario)
        log_result(data, result)

    evaluate()

    # Example real reading:
    # real = {
    #     "command": "OPEN_VALVE",
    #     "pressure": 72,
    #     "rpm": 1500,
    #     "valve_angle": 68,
    #     "vibration": 30,
    #     "previous_vibration": 27,
    #     "attempts": 2,
    #     "rejected": 0,
    # }
    # assurance_run(data=real)
