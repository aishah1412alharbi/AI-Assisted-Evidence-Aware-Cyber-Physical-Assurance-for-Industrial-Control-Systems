@echo off
cd /d "%~dp0"
where py >nul 2>nul
if %errorlevel%==0 (set PY=py) else (set PY=python)
%PY% -m pip install -r requirements.txt
%PY% SAIF_Final_AI_Evaluation_Code_P3_FIXED.py
pause
