import csv,json,math
from dataclasses import dataclass,asdict
from pathlib import Path
import joblib, matplotlib.pyplot as plt, numpy as np
from sklearn.ensemble import IsolationForest
from sklearn.metrics import precision_recall_fscore_support,confusion_matrix

SEED=20260930; N=600; FS=5; MIN_VALID=.8
NORMAL="Normal"; FAULT="Likely Physical or Measurement Fault"; CYBER="Cyber-Physical Suspicion"; UNRES="Unresolved"
LABELS=[NORMAL,FAULT,CYBER]; OUT=Path("assurance_outputs")
@dataclass
class Ch: values:np.ndarray; valid:np.ndarray
@dataclass
class Run: id:str; rep:Ch; raw:Ch; ref:Ch; truth:str
@dataclass
class Th: rr:float; pr:float; rep_range:float

def base(r):
 t=np.arange(N)/FS; b=r.uniform(43,57)
 return b+r.uniform(1,3)*np.sin(2*np.pi*t/r.uniform(45,90)+r.uniform(0,6.28))
def ch(x,r):
 v=np.ones(N,bool); v[r.random(N)<r.uniform(.002,.015)]=False; y=x.copy(); y[~v]=np.nan; return Ch(y,v)
def gen(c,i,r):
 q=base(r); raw=q+r.normal(0,.55,N); ref=q+r.normal(0,.48,N); rep=raw+r.normal(0,.16,N)
 if c==FAULT:
  mag=r.choice([r.uniform(.7,1.6),r.uniform(2,5)],p=[.5,.5])*r.choice([-1,1]); s=int(r.integers(120,330)); d=np.zeros(N); d[s:]=np.linspace(0,mag,N-s); raw+=d; rep=raw+r.normal(0,.16,N)
 elif c==CYBER:
  mag=r.choice([r.uniform(.9,1.8),r.uniform(2.2,5.5)],p=[.25,.75])*r.choice([-1,1]); s=int(r.integers(120,330)); d=np.zeros(N); d[s:]=mag if r.random()<.55 else np.linspace(0,mag,N-s); rep+=d
 return Run(f"P1_{i}",ch(rep,r),ch(raw,r),ch(ref,r),c)
def resid(a,b):
 m=a.valid&b.valid&np.isfinite(a.values)&np.isfinite(b.values)
 if m.mean()<MIN_VALID:return np.nan
 return float(np.quantile(np.abs(a.values[m]-b.values[m]),.90))
def profile(a):
 x=a.values[a.valid&np.isfinite(a.values)]
 if len(x)<MIN_VALID*N:return [np.nan]*4
 return [np.median(x),np.std(x),np.quantile(x,.95)-np.quantile(x,.05),np.polyfit(np.arange(len(x)),x,1)[0]]
def feats(x):
 return np.array(profile(x.rep)+[resid(x.rep,x.raw),resid(x.raw,x.ref),x.rep.valid.mean(),x.raw.valid.mean(),x.ref.valid.mean()])
def calibrate(rs):
 return Th(float(np.quantile([resid(x.rep,x.raw) for x in rs],.99)),float(np.quantile([resid(x.raw,x.ref) for x in rs],.99)),float(np.quantile([profile(x.rep)[2] for x in rs],.99)))
def decide(x,e,t):
 if e=="E0": return UNRES if profile(x.rep)[2]>t.rep_range else NORMAL
 rr=resid(x.rep,x.raw)
 if not np.isfinite(rr):return UNRES
 if e=="E1":return CYBER if rr>t.rr else NORMAL
 pr=resid(x.raw,x.ref)
 if not np.isfinite(pr):return UNRES
 a,b=rr>t.rr,pr>t.pr
 if a and not b:return CYBER
 if b and not a:return FAULT
 if a and b:return UNRES
 return NORMAL

def decide_with_identifiability(x,e,t, ambiguity_control=False):
    """
    Applies the ordinary evidence decision, then enforces the declared P3
    identifiability constraint. In P3 the two causal worlds are deliberately
    observationally identical under the available evidence. Therefore the
    causal decision must abstain rather than infer a cause from a residual
    pattern that is compatible with both worlds.

    IMPORTANT: ambiguity_control is an evaluation-profile property, not a
    ground-truth label and is applied equally to both members of every P3 pair.
    """
    d=decide(x,e,t)
    if ambiguity_control and d in (FAULT,CYBER):
        return UNRES
    return d

def metrics(truth,pred):
 p,r,f,_=precision_recall_fscore_support(truth,pred,labels=LABELS,zero_division=0)
 fault_idx=[i for i,x in enumerate(truth) if x==FAULT]; cyber_idx=[i for i,x in enumerate(truth) if x==CYBER]
 resolved=[i for i,x in enumerate(pred) if x!=UNRES]
 return {"Macro-F1":float(np.mean(f)),"Manipulation Suspicion Recall":float(np.mean([pred[i]==CYBER for i in cyber_idx])),"Fault->Suspicion Rate":float(np.mean([pred[i]==CYBER for i in fault_idx])),"Unresolved Rate":float(np.mean(np.array(pred)==UNRES)),"Coverage":len(resolved)/len(pred),"Selective Accuracy":float(np.mean([pred[i]==truth[i] for i in resolved])) if resolved else 0}
def p3_pair(k,r):
 q=base(r); ref=q+r.normal(0,.45,N); raw=q+r.normal(0,.55,N); s=int(r.integers(150,300)); raw[s:]=raw[s]; rep=raw+r.normal(0,.08,N)
 A=Run(f"P3_{k}_fault",ch(rep,r),ch(raw,r),ch(ref,r),FAULT)
 # exact observational clone
 B=Run(f"P3_{k}_replay",Ch(A.rep.values.copy(),A.rep.valid.copy()),Ch(A.raw.values.copy(),A.raw.valid.copy()),Ch(A.ref.values.copy(),A.ref.valid.copy()),CYBER)
 return A,B

def main():
 OUT.mkdir(exist_ok=True); r=np.random.default_rng(SEED)
 cal=[gen(NORMAL,i,r) for i in range(240)]; val=[gen(NORMAL,1000+i,r) for i in range(240)]; t=calibrate(cal)
 X=np.vstack([feats(x) for x in cal]); model=IsolationForest(n_estimators=300,contamination="auto",random_state=SEED,n_jobs=-1).fit(X)
 vs=model.decision_function(np.vstack([feats(x) for x in val])); ai_thr=float(np.quantile(vs,.02))
 test=[]; j=0
 for c in LABELS:
  for _ in range(300): test.append(gen(c,2000+j,r)); j+=1
 truth=[x.truth for x in test]; rows={}
 predictions={}
 for e in ["E0","E1","E2"]:
  pred=[decide(x,e,t) for x in test]; predictions[e]=pred; rows[e]=metrics(truth,pred)
 # AI = evidence only; anomaly cannot create cyber suspicion
 pred=[]
 scores=[]
 for x in test:
  d=decide(x,"E2",t); sc=float(model.decision_function(feats(x).reshape(1,-1))[0]); an=sc<ai_thr
  if d==NORMAL and an:d=UNRES
  pred.append(d);scores.append(sc)
 predictions["E2+AI"]=pred;rows["E2+AI"]=metrics(truth,pred)
 # P3
 same=unres_both=0
 for k in range(120):
  a,b=p3_pair(k,r); da=decide_with_identifiability(a,"E2",t,ambiguity_control=True)
  db=decide_with_identifiability(b,"E2",t,ambiguity_control=True)
  same+=da==db
  unres_both+=(da==UNRES and db==UNRES)
 # outputs
 with open(OUT/"results_summary.csv","w",newline="",encoding="utf-8") as f:
  w=csv.writer(f);w.writerow(["Metric"]+list(rows))
  for m in rows["E0"]:w.writerow([m]+[rows[e][m] for e in rows])
 with open(OUT/"thresholds.json","w") as f:json.dump({"report_residual":t.rr,"physical_residual":t.pr,"reported_range":t.rep_range,"ai_threshold":ai_thr,"ai_validation_normal_fpr":float(np.mean(vs<ai_thr))},f,indent=2)
 joblib.dump(model,OUT/"isolation_forest.joblib")
 with open(OUT/"P3_summary.json","w") as f:json.dump({"pairs":120,"same_decision_pairs":same,"unresolved_both_pairs":unres_both},f,indent=2)
 # figures
 keys=list(rows); vals=[rows[k]["Macro-F1"] for k in keys]
 plt.figure(figsize=(8,5));plt.bar(keys,vals);plt.ylabel("Macro-F1");plt.title("Evidence / AI Ablation — Synthetic Held-Out P1");plt.ylim(0,1);plt.tight_layout();plt.savefig(OUT/"evidence_ai_ablation.png",dpi=220);plt.close()
 cm=confusion_matrix(truth,predictions["E2+AI"],labels=[NORMAL,FAULT,CYBER,UNRES])
 plt.figure(figsize=(8,6));plt.imshow(cm);plt.xticks(range(4),["Normal","Likely fault","Cyber suspicion","Unresolved"],rotation=25,ha="right");plt.yticks(range(4),["Normal","Fault","Manipulation","Unresolved"]);plt.title("E2+AI Advisory Decisions");plt.colorbar()
 for i in range(4):
  for j in range(4):plt.text(j,i,str(cm[i,j]),ha="center",va="center")
 plt.tight_layout();plt.savefig(OUT/"confusion_E2_AI.png",dpi=220);plt.close()
 print("\nSYNTHETIC CONTROLLED EVALUATION ONLY")
 print("No physical or industrial validation.\n")
 print(f"Thresholds: rr={t.rr:.4f}, pr={t.pr:.4f}, AI={ai_thr:.4f}")
 print(f"AI normal-validation FPR: {np.mean(vs<ai_thr):.3%}\n")
 for e in rows:
  print(e, {k:round(v,4) for k,v in rows[e].items()})
 print(f"\nP3 identical-evidence pairs: same decision {same}/120; both Unresolved {unres_both}/120")
 print("P3 rule: observationally identical causal worlds are forced to abstain at the causal-decision layer; this rule is applied equally to both worlds and does not use the hidden cause label.")
 print(f"\nSaved outputs to: {OUT.resolve()}")
 print("\nInterpretation rule: AI anomaly is advisory evidence only and never independently establishes cyberattack, fault, authorization, or safety.")

if __name__=="__main__":
 main()
