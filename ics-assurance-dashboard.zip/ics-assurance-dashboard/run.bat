@echo off
cd /d "%~dp0"
where py >nul 2>nul
if %errorlevel%==0 (set PY=py) else (set PY=python)
%PY% -m pip install -r requirements.txt
start "" cmd /c "timeout /t 4 >nul & start http://localhost:5050"
%PY% server.py
pause
