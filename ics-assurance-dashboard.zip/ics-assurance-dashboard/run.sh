#!/usr/bin/env bash
cd "$(dirname "$0")"
python3 -m pip install -r requirements.txt
( sleep 3; if command -v open >/dev/null; then open http://localhost:5050; elif command -v xdg-open >/dev/null; then xdg-open http://localhost:5050; fi ) &
python3 server.py
