AI-Assisted Evidence-Aware Cyber-Physical Assurance for Industrial
Control Systems - live dashboard (real Python engine + Flask)

HOW TO RUN
  Windows  : double-click run.bat
  Mac/Linux: bash run.sh
  Manual   : pip install -r requirements.txt   then   python server.py
  Then open http://localhost:5050  (run.bat / run.sh open it for you)
  Stop the server with Ctrl+C.

FILES
  SAIF_Final_AI_Evaluation_Code_P3_FIXED.py
                            standalone synthetic evaluation (E0/E1/E2/E2+AI
                            ablation + P3 identifiability check). Run it
                            The dashboard runs it automatically the first time
                            server.py starts (results appear in the "Offline
                            Evaluation" card at the bottom of the page), and the
                            "Re-run evaluation" button runs it again. You can also
                            run it by hand: python SAIF_Final_AI_Evaluation_Code_P3_FIXED.py
                            Outputs go to the assurance_outputs/ folder.
  assurance_engine.py   the team's algorithm (unchanged). Makes every
                            security decision, including the AI (Isolation
                            Forest) layer. Trains itself on simulated
                            normal-operation data the first time it is
                            imported (~1-2 seconds).
  server.py                 asks the engine for one simulated sensor
                            reading every DP_TICK_SECONDS, runs the
                            engine's analyze() on it unchanged, and serves
                            the result as JSON at /api/state.
  static/index.html          the dashboard. Reads /api/state once a second.

WHAT THE DASHBOARD SHOWS (matches assurance_engine.py exactly)
  - Simulated Sensor Data       Pressure / RPM / Valve Angle / Vibration,
                                against the engine's own SAFE_LIMITS.
  - Physical Safety Validation  engine.physical_rules()
  - Physical Fingerprint        engine.physical_fingerprint()
  - Expected vs. Observed       engine.expected_vs_observed() - also shown
                                on the Current Command card.
  - Cyber-Behavior Analysis     engine.cyber_behavior_analysis()
  - Evidence Context            engine.context_engine()
  - AI Anomaly Detection        engine.ai_analysis() (Isolation Forest);
                                "AI trained on: ..." in the footer shows
                                engine.AI_TRAINING_SOURCE.
  - Risk Score / System Status  engine.classify_risk() -> score + SAFE /
                                SUSPICIOUS / CRITICAL (shown separately
                                from the Decision, per the spec).
  - Decision: ALLOW / VERIFY / BLOCK / FLAG
        ALLOW / VERIFY / BLOCK come from engine.ACTIONS[level].
        FLAG is the engine's own AI-only override (see print_report):
        triggered when the AI layer alone flags an anomaly but every
        rule-based check stays SAFE - shown as "review before
        escalation", not a block, since the AI does not by itself
        prove an attack occurred.

  A permanent "SIMULATION MODE" banner and the sensor cards' framing make
  clear that all data is simulated for prototype testing - nothing here
  is presented as a real hardware reading or a confirmed attack.

NOTES
  - The dashboard needs the server running. Opening index.html by
    double-click will show "Engine offline".
  - Sensor readings come from the engine's own generate_sensor_data() -
    a stand-in for real hardware. To use real sensors, feed real
    readings into engine.analyze() from server.py's tick() function;
    the engine and dashboard stay the same.
  - Scenario mix (how often each of the engine's four scenarios -
    NORMAL / SUSPICIOUS / CRITICAL / STEALTH_SCENARIO - is asked for)
    is set in server.py's SCENARIOS tuple. STEALTH_SCENARIO is the one
    that stays inside every rule-based limit and is only ever caught by
    the AI layer - it is what produces the FLAG state.
  - Optional environment variables:
      DP_TICK_SECONDS  seconds between readings   (default 2.5)
      DP_PORT          port                        (default 5050)
      DP_HOST          127.0.0.1 = this computer only;
                       0.0.0.0   = other devices on the same Wi-Fi too
