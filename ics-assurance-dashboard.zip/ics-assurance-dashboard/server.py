"""
ICS Cyber-Physical Assurance - live dashboard server

Every security decision comes from the team's own Python engine
(assurance_engine.py, saved unchanged from what was supplied). This
file only:

  1. asks the engine to simulate a sensor reading (a stand-in for real
     hardware; the engine's own generate_sensor_data() is what actually
     produces the numbers - not custom logic in this file),
  2. runs the engine's analyze() on every reading,
  3. serves the results to the dashboard as JSON.

Run:   python server.py
Open:  http://localhost:5050
"""

import csv
import json
import os
import platform
import random
import subprocess
import sys
import threading
import time
from collections import deque
from datetime import datetime

from flask import Flask, jsonify, request, send_from_directory

import assurance_engine as engine  # the team's algorithm, used as-is

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
STATIC_DIR = os.path.join(BASE_DIR, "static")

TICK_SECONDS = float(os.environ.get("DP_TICK_SECONDS", "2.5"))
HOST = os.environ.get("DP_HOST", "127.0.0.1")
PORT = int(os.environ.get("DP_PORT", "5050"))

HISTORY_LEN = 10   # readings kept for the trend chart
EVENTS_LEN = 8      # events kept for the events list

# How often each of the engine's own scenarios is asked for.
# STEALTH_SCENARIO stays inside every rule-based limit and is only ever
# caught by the AI layer, so it gets a healthy share here - otherwise a
# live demo could run for a while without ever seeing it.
SCENARIOS = (
    ("NORMAL", 0.40, "Normal operation"),
    ("SUSPICIOUS", 0.25, "Suspicious cyber-physical behaviour"),
    ("CRITICAL", 0.15, "Critical out-of-limit condition"),
    ("STEALTH_SCENARIO", 0.20, "Synthetic low-and-slow anomalous scenario"),
)
SCENARIO_LABEL = {name: label for name, _, label in SCENARIOS}

SENSOR_LABELS = {"pressure": "Pressure", "rpm": "RPM", "valve_angle": "Valve Angle", "vibration": "Vibration"}
SENSOR_DIGITS = {"pressure": 1, "rpm": 0, "valve_angle": 1, "vibration": 1}

# Colour class the dashboard uses for each engine status word.
SEVERITY = {
    "NORMAL": "ok", "CONSISTENT": "ok", "AI NORMAL": "ok",
    "UNUSUAL": "warn", "LOW": "warn", "MEDIUM": "warn", "SUSPICIOUS": "warn",
    "ANOMALY": "crit", "ABNORMAL": "crit", "MISMATCH": "crit", "HIGH": "crit",
    "AI ANOMALY": "warn",  # a flag for review, not on its own a critical finding
}

# code -> (css accent class, icon name)
DECISION_META = {
    "ALLOW": ("ok", "shield-check"),
    "VERIFY": ("warn", "hourglass"),
    "BLOCK": ("crit", "lock"),
    "FLAG": ("flag", "alert"),
}
EXEC_FOR_CODE = {"ALLOW": "EXECUTED", "VERIFY": "PENDING VERIFICATION", "BLOCK": "NOT EXECUTED", "FLAG": "PENDING REVIEW"}

# --------------------------------------------------------------------------
# Offline evaluation (SAIF_Final_AI_Evaluation_Code_P3_FIXED.py)
# Run as a separate process (its own matplotlib / joblib work) and read back
# from the files it writes into assurance_outputs/.
# --------------------------------------------------------------------------
EVAL_SCRIPT = os.path.join(BASE_DIR, "SAIF_Final_AI_Evaluation_Code_P3_FIXED.py")
EVAL_DIR = os.path.join(BASE_DIR, "assurance_outputs")
eval_lock = threading.Lock()
eval_status = {"running": False, "error": None, "finished_at": None}


def _run_evaluation():
    try:
        env = dict(os.environ, MPLBACKEND="Agg")
        proc = subprocess.run([sys.executable, EVAL_SCRIPT], cwd=BASE_DIR, env=env,
                              capture_output=True, text=True, timeout=1800)
        err = None if proc.returncode == 0 else (proc.stderr.strip().splitlines() or ["Evaluation failed"])[-1]
    except Exception as exc:  # noqa: BLE001
        err = str(exc)
    with eval_lock:
        eval_status.update(running=False, error=err, finished_at=datetime.now().strftime("%H:%M:%S") if not err else None)


def start_evaluation():
    with eval_lock:
        if eval_status["running"]:
            return False
        eval_status.update(running=True, error=None)
    threading.Thread(target=_run_evaluation, daemon=True).start()
    return True


def read_evaluation():
    out = {"ready": False, "metrics": [], "columns": [], "p3": None, "thresholds": None, "figures": []}
    try:
        with open(os.path.join(EVAL_DIR, "results_summary.csv"), newline="", encoding="utf-8") as f:
            rows = list(csv.reader(f))
        out["columns"] = rows[0][1:]
        out["metrics"] = [{"name": r[0], "values": [float(x) for x in r[1:]]} for r in rows[1:]]
        with open(os.path.join(EVAL_DIR, "P3_summary.json"), encoding="utf-8") as f:
            out["p3"] = json.load(f)
        with open(os.path.join(EVAL_DIR, "thresholds.json"), encoding="utf-8") as f:
            out["thresholds"] = json.load(f)
        out["figures"] = [
            {"title": "Evidence / AI ablation (Macro-F1)", "url": "/assurance_outputs/evidence_ai_ablation.png"},
            {"title": "E2+AI advisory decisions (confusion matrix)", "url": "/assurance_outputs/confusion_E2_AI.png"},
        ]
        out["ready"] = True
    except (OSError, ValueError, IndexError, KeyError):
        pass
    return out


app = Flask(__name__, static_folder=STATIC_DIR, static_url_path="/static")
lock = threading.Lock()

state = {}
history = deque(maxlen=HISTORY_LEN)
events = deque(maxlen=EVENTS_LEN)
_seq = 0
_prev_level = None
_prev_code = None
_prev_flags = set()
_scenario_hold = {"case": "NORMAL", "left": 0}


# --------------------------------------------------------------------------
# Scenario picking (which of the engine's own scenarios to ask for)
# --------------------------------------------------------------------------

def pick_scenario():
    roll, total = random.random(), 0.0
    for name, weight, _ in SCENARIOS:
        total += weight
        if roll < total:
            return name
    return "NORMAL"


def next_scenario():
    """Hold each scenario for a few readings so the dashboard is readable."""
    if _scenario_hold["left"] <= 0:
        _scenario_hold["case"] = pick_scenario()
        _scenario_hold["left"] = random.randint(3, 5)
    _scenario_hold["left"] -= 1
    return _scenario_hold["case"]


def fmt(key, value):
    """Reading with its unit, e.g. '76.3 bar' or '92.5\u00b0'."""
    number = f"{value:.{SENSOR_DIGITS[key]}f}"
    if key == "valve_angle":
        return f"{number}\u00b0"
    return f"{number} {engine.UNITS[key]}"


def decide_action(result):
    """Same ALLOW / VERIFY / BLOCK mapping as engine.ACTIONS, plus the
    engine's own FLAG override for an AI-only anomaly (see print_report)."""
    level = result["level"]
    code = {"SAFE": "ALLOW", "SUSPICIOUS": "VERIFY", "CRITICAL": "BLOCK"}[level]
    title = engine.ACTIONS[level]

    non_ai_score = result["score"] - (25 if result["ai"] == "AI ANOMALY" else 0)
    if result["ai"] == "AI ANOMALY" and non_ai_score < 40 and level == "SAFE":
        code = "FLAG"
        title = "FLAG \u2014 AI anomaly detected; review before escalation"

    return code, title


# --------------------------------------------------------------------------
# Dashboard payload built from the engine's own results
# --------------------------------------------------------------------------

def analysis_rows(data, r):
    if r["violations"]:
        rule_detail = "; ".join(f"{SENSOR_LABELS[v]} outside safe range ({fmt(v, data[v])})" for v in r["violations"])
    else:
        rule_detail = "All sensor readings within safe limits"

    expected = engine.EXPECTED_ANGLE[data["command"]]

    rows = [
        ("physical_rules", "Physical Safety Validation", r["rule"], rule_detail),
        ("physical_fingerprint", "Physical Fingerprint", r["fingerprint"],
         f"Vibration change \u0394 = {r['fp_change']:.1f} mm/s"),
        ("expected_vs_observed", "Expected vs. Observed", r["consistency"],
         f"Valve angle ({data['valve_angle']:.1f}\u00b0) vs. expected ({expected}\u00b0)"),
        ("cyber_behavior", "Cyber-Behavior Analysis", r["cyber_behavior"],
         f"{data['attempts']} command attempts, {data['rejected']} rejected"),
        ("evidence_context", "Evidence Context", r["context"],
         "Combines the indicators above into one correlation level"),
        ("ai_anomaly", "AI Anomaly Detection", r["ai"],
         f"Isolation Forest \u00b7 anomaly score {r['ai_score']:+.3f}"),
    ]
    return [{"key": k, "label": lbl, "status": st, "severity": SEVERITY[st], "detail": dt}
            for k, lbl, st, dt in rows]


def record_events(data, r, code, now):
    """Turn one engine result into human-readable events (newest first)."""
    global _prev_level, _prev_code, _prev_flags
    new, flags = [], set()
    level = r["level"]
    sev_for_level = {"SAFE": "ok", "SUSPICIOUS": "warn", "CRITICAL": "crit"}

    if level != _prev_level:
        new.append((f"Risk level changed to {level}", sev_for_level[level]))
    if code != _prev_code:
        verb = {"ALLOW": "Command allowed", "VERIFY": "Verification requested",
                "BLOCK": "Command blocked", "FLAG": "Flagged for review"}[code]
        new.append((f"{verb}: {data['command']}", DECISION_META[code][0]))

    # Warnings are logged when they first appear (or change), not on every reading.
    def once(flag, text, severity):
        flags.add(flag)
        if flag not in _prev_flags:
            new.append((text, severity))

    if r["violations"]:
        parts = ", ".join(f"{SENSOR_LABELS[v]} ({fmt(v, data[v])})" for v in r["violations"])
        once("limit:" + ",".join(r["violations"]), f"Safety limit exceeded: {parts}", "crit")
    if r["cyber_behavior"] == "SUSPICIOUS":
        once("cyber", f"Suspicious command-activity pattern ({data['attempts']} attempts, {data['rejected']} rejected)", "warn")
    if r["fingerprint"] != "NORMAL":
        once("vibration:" + r["fingerprint"], f"Vibration change detected (\u0394 {r['fp_change']:.1f} mm/s)",
             "crit" if r["fingerprint"] == "ABNORMAL" else "warn")
    if r["ai"] == "AI ANOMALY":
        once("ai", "AI anomaly detector flagged an unusual pattern", "warn")

    for text, severity in reversed(new):  # first item ends up on top
        events.appendleft({"time": now, "text": text, "severity": severity})

    _prev_level, _prev_code, _prev_flags = level, code, flags


def tick():
    """Ask the engine for one simulated reading, analyze it, publish the result."""
    global _seq, state

    scenario = next_scenario()
    data = engine.generate_sensor_data(scenario)   # the engine's own simulator - untouched
    _, r = engine.analyze(data, verbose=False, use_ai=True)  # the engine's own pipeline - untouched
    code, title = decide_action(r)
    now = datetime.now().strftime("%H:%M:%S")

    sensors = []
    for key in ("pressure", "rpm", "valve_angle", "vibration"):
        low, high = engine.SAFE_LIMITS[key]
        value = data[key]
        sensors.append({
            "key": key, "label": SENSOR_LABELS[key], "unit": engine.UNITS[key],
            "value": round(value, SENSOR_DIGITS[key]) if SENSOR_DIGITS[key] else int(round(value)),
            "status": "OK" if low <= value <= high else "WARNING",
            "range": [low, high],
        })

    with lock:
        _seq += 1
        history.append({
            "seq": _seq,
            "pressure": round(data["pressure"], 2),
            "rpm": data["rpm"],
            "valve_angle": round(data["valve_angle"], 2),
            "vibration": round(data["vibration"], 2),
        })
        record_events(data, r, code, now)

        accent, icon = DECISION_META[code]
        state = {
            "seq": _seq,
            "time": now,
            "scenario": {"name": scenario, "label": SCENARIO_LABEL[scenario]},
            "sensors": sensors,
            "analysis": analysis_rows(data, r),
            "indicators": r["reasons"],  # the engine's own reasons, verbatim
            "risk": {"score": r["score"], "level": r["level"]},
            "decision": {"code": code, "title": title, "accent": accent, "icon": icon},
            "command": {
                "name": data["command"],
                "expected_angle": engine.EXPECTED_ANGLE[data["command"]],
                "actual_angle": round(data["valve_angle"], 1),
                "consistency": r["consistency"],
                "execution": EXEC_FOR_CODE[code],
            },
            "history": list(history),
            "events": list(events)[:5],
            "meta": {
                "engine": "assurance_engine.py",
                "python": platform.python_version(),
                "tick_seconds": TICK_SECONDS,
                "ai_training_source": engine.AI_TRAINING_SOURCE,
                "simulation_note": "All sensor data shown is simulated for prototype testing.",
            },
        }


def simulation_loop():
    while True:
        time.sleep(TICK_SECONDS)
        tick()


# --------------------------------------------------------------------------
# Routes
# --------------------------------------------------------------------------

@app.route("/")
def index():
    return send_from_directory(STATIC_DIR, "index.html")


@app.route("/api/state")
def api_state():
    with lock:
        return jsonify(state)


@app.route("/api/evaluation")
def api_evaluation():
    data = read_evaluation()
    with eval_lock:
        data["status"] = dict(eval_status)
    return jsonify(data)


@app.route("/api/evaluation/run", methods=["POST"])
def api_evaluation_run():
    return jsonify({"started": start_evaluation()})


@app.route("/assurance_outputs/<path:name>")
def evaluation_file(name):
    return send_from_directory(EVAL_DIR, name)


@app.after_request
def no_cache(response):
    if request.path == "/" or request.path.startswith(("/api/", "/assurance_outputs/")):
        response.headers["Cache-Control"] = "no-store"
    return response


if __name__ == "__main__":
    tick()  # so the very first request already has data
    if not os.path.exists(os.path.join(EVAL_DIR, "results_summary.csv")):
        start_evaluation()  # first launch: generate the evaluation results in the background
    threading.Thread(target=simulation_loop, daemon=True).start()
    print(f"Dashboard is running.  Open http://localhost:{PORT}")
    print("Press Ctrl+C to stop.")
    app.run(host=HOST, port=PORT, debug=False, threaded=True)
